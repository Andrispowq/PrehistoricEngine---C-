<elements>
  <summary>
    <attribution license="cc4" from="Microsoft" modified="false" />
    <para>The <see cref="N:System.Data.Sql" /> namespace contains classes that support SQL Server-specific functionality.</para>
  </summary>
  <remarks>
    <attribution license="cc4" from="Microsoft" modified="false" />
    <para>For information about the functionality that the classes within this namespace support, see <format type="text/html"><a href="ddf1c83c-9d40-45e6-b04d-9828c6cbbfdc">Enumerating Instances of SQL Server</a></format> and <format type="text/html"><a href="0f0ba1a1-3180-4af8-87f7-c795dc8f8f55">Using Query Notifications</a></format>.</para>
    <block subset="none" type="note">
      <para>In beta releases of ADO.NET version 2.0, the <see cref="N:System.Data.Sql" /> namespace also contained classes for use with SQL Server common language runtime (CLR) integration. However, those classes have been moved into their own namespace, <see cref="N:Microsoft.SqlServer.Server" />. For more information about using SQL Server CLR integration, see <format type="text/html"><a href="c7a324c4-160d-44c2-b593-641af06eca61">Using SQL Server Common Language Runtime Integration</a></format>. </para>
    </block>
  </remarks>
  <class name="SqlDataSourceEnumerator" fullname="System.Data.Sql.SqlDataSourceEnumerator" assembly="System.Data">
    <summary>
      <attribution license="cc4" from="Microsoft" modified="false" />
      <para>Provides a mechanism for enumerating all available instances of SQL Server within the local network.</para>
    </summary>
    <remarks>
      <attribution license="cc4" from="Microsoft" modified="false" />
      <para>Both SQL Server 2000 and SQL Server 2005 make it possible for applications to determine the existence of SQL Server instances within the current network. The <see cref="T:System.Data.Sql.SqlDataSourceEnumerator" /> class exposes this information to the application developer, providing a <see cref="T:System.Data.DataTable" /> containing information about all the available servers. This returned table contains a list of server instances that matches the list provided when a user attempts to create a new connection, and on the <paramref name="Connection Properties" /> dialog box, expands the drop-down list containing all the available servers.</para>
    </remarks>
  </class>
  <class name="SqlNotificationRequest" fullname="System.Data.Sql.SqlNotificationRequest" assembly="System.Data">
    <summary>
      <attribution license="cc4" from="Microsoft" modified="false" />
      <para>Represents a request for notification for a given command. </para>
    </summary>
    <remarks>
      <attribution license="cc4" from="Microsoft" modified="false" />
      <para>This class provides low-level access to the query notification services exposed by SQL Server 2005. For most applications the <see cref="T:System.Data.SqlClient.SqlDependency" /> class provides a simpler way of using query notifications. However, if you need fine control over when notifications occur, or you need to customize the message data returned as part of a notification, the <see cref="T:System.Data.Sql.SqlNotificationRequest" /> class is the one to use.</para>
    </remarks>
  </class>
</elements>